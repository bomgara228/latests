import React, { Suspense, createContext } from 'react';
import './App.css';
import { Header } from './components/Header/Header';
import { BrowserRouter } from "react-router-dom";
import { Footer } from './components/Footer/Footer';
import { AppRouters } from './components/AppRouters/AppRouters';
import { Provider } from 'react-redux'
import { store } from './store'
import { Loading } from './components/Loading/Loading';


export const AppContext = createContext()

const App = () => (
  <Suspense fallback={<div><Loading/></div>}>
    <Provider store={store}>
      <BrowserRouter>
        <div className="App">
          <Header />
          <AppContext.Provider value={{ test: 'test', age: 20 }}>
            <AppRouters />
          </AppContext.Provider>
        </div>
        <Footer />
      </BrowserRouter >
    </Provider>
  </Suspense>
);


export default App;



