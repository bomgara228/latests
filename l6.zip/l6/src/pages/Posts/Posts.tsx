import { useEffect, useState, KeyboardEvent, useRef } from "react";
import { instance } from "../../api";
import styles from './Posts.module.css';
import { Button } from "../../components/Button/Button";
import { Loading } from "../../components/Loading/Loading";
import Tilt from 'react-parallax-tilt'

interface PosType {
    body: string
    id: number
    title: string
    userId: number
}

type Nullable<T> = null | T

 const Posts = () => {
    const [posts, setPosts] = useState<PosType[]>([] as PosType[])
    const [filterPosts, setFilterPosts] = useState<PosType[]>(posts)
    const [activePost, setActivePost] = useState<PosType>({} as PosType)
    const [isShow, setIsShow] = useState<boolean>(false)
    const [isLoading, setIsLoading] = useState<boolean>(false)
    const [isShowInput, setIsShowInput] = useState<boolean>(false)
    const [text, setText] = useState<string>(activePost.body)
    const [sortText, setSortText] = useState<string>('')
    const [isReversed,setIsRevesed]=useState<boolean>(false)

    const modalRef = useRef<Nullable<HTMLDivElement>>(null)

    const handleActivePostItem = (item: PosType): void => {
        setIsShow(true)
        setActivePost(item)
    }

    const closeModalByEscapePress = (event: KeyboardEvent): void => {

        if (event.key === 'Escape') {
            setIsShow(false)
            setIsShowInput(false)
        }
    }

    const clickOutsideModal = (event: MouseEvent): void => {
        if (!modalRef?.current?.contains(event.target as Node)) {
            setIsShow(false)
            setIsShowInput(false)
        }

    }

    const copyPostDescription = async (description: string): Promise<void> => {
        console.log("description ", description)
        await navigator.clipboard.writeText(description)
    }

    const updateText = (event: KeyboardEvent<HTMLLIElement>) => {
        setSortText(event.currentTarget.value.trim())
    }
    const clearInputValue=()=>{
        setSortText('')
    }
    const reverseArray=()=>{
        setIsRevesed(!isReversed)
    }

    useEffect(() => {
        setIsLoading(true)
        instance.get('/posts?_limit=100&_page={co}').then(({ data }) => {
            setPosts(data)
            setFilterPosts(data)

            setTimeout(() => {
                setIsLoading(false)
            }, 700)
        })

        document.addEventListener<any>('keyup', closeModalByEscapePress)
        document.addEventListener('click', clickOutsideModal, true)

        return () => {
            document.removeEventListener<any>('keyup', closeModalByEscapePress)
            document.removeEventListener('click', clickOutsideModal, true)
        }
    }, [])

    useEffect(()=>{
        if(sortText){
            let filteredArray:PosType[]=posts.filter((item:PosType)=>item.title.toLowerCase().includes(sortText.toLowerCase()))
            if(isReversed){
                filteredArray=filteredArray.reverse()
            }
            console.log(filteredArray)
            setFilterPosts(filteredArray)

            return
        }
        if(isReversed){
            setFilterPosts(posts.reverse())
            return
        }
        setFilterPosts(posts)
    },[sortText,isReversed])

    return (
        <div className={styles.wrapper}>
            {isLoading ? <Loading /> : (
                <>
                <div>
                    <div>
                    <input type="text" value={sortText} onChange={updateText}/>
                    {sortText && <button onClick={clearInputValue}>X</button>}
                    </div>
                    <div>
                        <button onClick={reverseArray}>Reverse</button>
                    </div>
                </div>
                    <ol>
                        {filterPosts.map((item: PosType, index: number) => (
                            <Tilt key={item.id}>
                                <li  className={styles.item}>
                                    <h2>{item.id}</h2>
                                    <h3>{item.title}</h3>
                                    <p>{item.body}</p>
                                    <div>
                                        <Button click={() => handleActivePostItem(item)}>Open</Button>
                                        <Button click={() => copyPostDescription(item.body)}>Copy</Button>
                                    </div>

                                </li>
                            </Tilt>
                        ))}
                    </ol>

                    {isShow && (
                        <div className={styles.modalWrapper}>
                            <div ref={modalRef} className={styles.modalContainer}>
                                <h2>{activePost.id}. {activePost.title}</h2>
                                {isShowInput ? (
                                    <textarea
                                        style={{ width: '400px', height: '200px', resize: 'none' }}
                                        autoFocus
                                        value={activePost.body}
                                        onBlur={() => setIsShowInput(false)}
                                    />
                                ) : (
                                    <p onDoubleClick={() => setIsShowInput(true)}>{activePost.body}</p>
                                )}

                                <div>
                                    <Button click={() => setIsShow(false)}>Close</Button>
                                    <Button click={() => setIsShowInput(true)}>Edit</Button>
                                </div>

                            </div>
                        </div>
                    )}
                </>
            )}

        </div>
    )
}
export default Posts