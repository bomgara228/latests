import { Button } from '../Button/Button';
import React, { useState, FC, ChangeEvent } from 'react';

type IdType = number | string

interface ItemType {
    id: IdType
    title: string
    isDone: boolean
}

interface ListItemProps {
    item: ItemType
    deleteByid: (id: IdType) => void
    updateStatus: (status: boolean, id: IdType) => void
    updateItemText: (text: string, id: IdType) => void
    index: number
}

export const ListItem: FC<ListItemProps> = ({
    item, deleteByid, updateStatus, updateItemText, index
}) => {

    const [isShow, setIsShow] = useState<boolean>(true)
    const [isShowInput, setIsShowInput] = useState<boolean>(false)

    const [newText, setNewText] = useState<string>(item.title)

    const updateText = (event: ChangeEvent<HTMLInputElement>): void => {
        setNewText(event.target.value.trim())
    }

    const updateItemTitle = (): void => {
        updateItemText(newText, item.id)
    }

    const setNewTitle = () => {
        updateItemTitle()
        setIsShowInput(false)
    }

    const SetNewTitleOnEnterPress = (event: any) => {
        if(event.key === 'Enter' || event.charCode === 13){
            setNewTitle()
        }

        console.log("code", event.charCode)
    }

    return (
        <li>
            {
                isShow && (
                    <>
                        <label>
                            <input
                                type="checkbox"
                                checked={item.isDone}
                                onChange={(event) => updateStatus(event.target.checked, item.id)}
                            />
                            <span>{index + 1}. </span>
                            {
                                isShowInput ? (
                                    <input
                                        value={newText}
                                        onBlur={setNewTitle}
                                        onChange={updateText}
                                        onKeyPress={SetNewTitleOnEnterPress}
                                        autoFocus
                                    />
                                ) : (
                                    <span onDoubleClick={() => setIsShowInput(true)}>
                                        {item.title}
                                    </span>
                                )
                            }

                        </label>


                        <Button click={() => deleteByid(item.id)} isDelType>
                            Delete
                        </Button>
                    </>
                )
            }
            <Button click={() => setIsShow(!isShow)}>
                change visibility
            </Button>
            <Button click={() => setIsShowInput(true)}>
                edit
            </Button>
        </li>
    )
}
