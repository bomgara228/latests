import { FC } from 'react'
import { useNavigate } from "react-router-dom";
import { Button } from '../Button/Button';
import styles from './UserItem.module.css'

interface PropsType {
    item: {
        title: string
        id: string
    }
}

export const UserItem: FC<PropsType> = (item) => {
    const navigate = useNavigate()

    return (
        <li className={styles.wrapper}>{item.item.title}            <Button click={() => navigate(`/user/${item.item.id}`)}>
            show user
        </Button>
        </li>
    )
}