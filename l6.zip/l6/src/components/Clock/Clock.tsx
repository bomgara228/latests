import { useEffect, useRef, useState } from 'react'

const changeTimestamp = (time: number): string => {
    return time.toString().padStart(2, '0')
}

// const str = 'xsdgfdfAkdksAAAklfdg;l'

// console.log("top", str.toUpperCase())
// console.log("low", str.toLowerCase())

// const num = 0.02878942634283642

// console.log(num.toFixed(2))
// console.log(num.toFixed(0))

//@ts-ignore
// console.log(NaN === NaN)
// console.log(typeof NaN)

// console.log(null == undefined)
// console.log(null === undefined)

export const Clock = () => {
    const [date, setDate] = useState(new Date())

    const timeRef = useRef<any>(null)

    useEffect(() => {
        timeRef.current = setInterval(() => {
            setDate(new Date())
        }, 1000)

        return () => {
            clearInterval(timeRef.current)
        }
    }, [])

    return (
        <div>
            <span>{date.getHours()}</span>:
            <span>{changeTimestamp(date.getMinutes())}</span>:
            <span>{changeTimestamp(date.getSeconds())}</span>
        </div>
    )
}