import React, { useState, FC, MouseEvent } from 'react';
import styles from './MouseMove.module.css'

interface Positions {
    posX: number
    posY: number
}

const MouseMove: FC = () => {
    const [positions, setPositions] = useState<Positions>({
        posX: 0,
        posY: 0,
    })

    const updatePositions = (event: MouseEvent<HTMLDivElement>): void => {
        setPositions({
            posX: event.screenX,
            posY: event.screenY,
        })
    }

    return (
        <div className={styles.container} onMouseMove={updatePositions}>
            <p style={
                { color: `rgb(${positions.posX / 5}, ${positions.posX / 5}, ${positions.posX / 5})` }
            }>
                posX: {positions.posX}
            </p>
            <p>posY: {positions.posY}</p>
        </div>
    )
}

export default MouseMove
