import { Button } from '../Button/Button';
import React, { useState, FC, ChangeEvent } from 'react';
import styles from "../../pages/Blog/Blog.module.css"
type IdType = number | string

interface BlogType {
    id: IdType
    img:string
    title: string
    author: string,
    discription:string
}

interface BlogItemProps {
    item: BlogType
    deleteByid: (id: IdType) => void
    updateItemText: (text: string, id: IdType) => void
    index: number
}

export const BlogItem: FC<BlogItemProps> = ({
    item, deleteByid, updateItemText
}) => {
    const [isShowInput, setIsShowInput] = useState<boolean>(false)

    const [newText, setNewText] = useState<string>(item.title)

    const updateText = (event: ChangeEvent<HTMLInputElement>): void => {
        setNewText(event.target.value.trim())
    }

    const updateItemTitle = (): void => {
        updateItemText(newText, item.id)
    }

    const setNewTitle = () => {
        updateItemTitle()
        setIsShowInput(false)
    }
    const SetNewTitleOnEnterPress = (event: any) => {
        if(event.key === 'Enter' || event.charCode === 13){
            setNewTitle()
        }
    }

    return (
        <li className={styles.container}>
                        <label>
                            <h2>{item.title}</h2>
                            <h4><img src={item.img} alt="" />{item.author}</h4>
                            {
                                isShowInput ? (
                                    <input
                                        value={newText}
                                        onChange={updateText}
                                        onKeyPress={SetNewTitleOnEnterPress}
                                        autoFocus
                                    />
                                ) : (
                                    <p>{item.discription}</p>
                        
                                )
                            }
                        </label>
                            

                        <Button click={()=>setIsShowInput(!isShowInput)}>{isShowInput?'Save':"Edit"}</Button>
                        <Button click={() => deleteByid(item.id)} isDelType>
                            Delete
                        </Button>
        </li>
    )
}
