import {lazy, useEffect, useRef, useState } from 'react';
import { User } from '../../pages/User/User';
import { Route, Routes } from "react-router-dom";
import { Blog } from '../../pages/Blog/Blog';

const HEADER_HEIGT = 40;
const FOOTER_HEIGHT = 40;
const BODY_STATYC_HEIGHT = document.querySelector<HTMLBodyElement>('body');
const Home = lazy(()=>import('../../pages/Home'))
const ToDoList = lazy(()=>import('../../pages/ToDoList'))
const Posts = lazy(()=>import('../../pages/Posts/Posts'))

export const AppRouters = () => {

    const refMain = useRef(null)

    //@ts-ignore
    const [mainHeight, setMainHeight] = useState(BODY_STATYC_HEIGHT?.getBoundingClientRect()?.height - FOOTER_HEIGHT - HEADER_HEIGT)

    useEffect(() => {
        //@ts-ignore
        //console.log(refMain.current?.getBoundingClientRect())
    }, [])

    useEffect(() => {
        window.addEventListener('resize', () => {
            //@ts-ignore
            setMainHeight(BODY_STATYC_HEIGHT?.getBoundingClientRect().height - FOOTER_HEIGHT - HEADER_HEIGT)
        })
    }, [])

    return (
        <main ref={refMain} style={{ minHeight: '100vh'}}>
            <Routes>
                <Route path='/' element={<Home />} />
                <Route  path='/todolist' element={<ToDoList />} >
                    <Route path='news' element={<div>news
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque autem eveniet beatae eos cupiditate, deserunt asperiores placeat labore ab totam amet at qui, voluptatum saepe odit velit quo in iste.</p>
                    </div>}/>
                </Route>
                <Route path='/posts' element={<Posts />} />
                <Route path='/blog' element={<Blog />} />
                <Route path='/user/:id' element={<User />} />
                <Route path='*' element={<div>404 page</div>} />
            </Routes>
        </main>
    )
}
