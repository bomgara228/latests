import { ReactNode, FC } from 'react'
import styles from './Button.module.scss'

interface ButtonProps {
    type?: "button" | "submit" | "reset"
    children: ReactNode
    isDisabled?: boolean
    click: () => void
    isDelType?: boolean
}


export const Button:FC<ButtonProps> = ({
    children,
    type = 'button',
    isDisabled = false,
    click,
    isDelType = false
}) => {

    const style = isDelType ? `${styles.del}` : `${styles.btn}`

    return (
        <button
            className={style}
            onClick={click}
            type={type}
            disabled={isDisabled}
        >
            {children}
        </button>
    )
}