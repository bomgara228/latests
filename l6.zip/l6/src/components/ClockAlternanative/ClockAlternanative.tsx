import { useEffect, useRef, useState } from 'react'
import styles from './ClockAlternanative.module.css'
import { Button } from '../Button/Button'

const DEG_FOR_SECONDS_OR_MINUTES = 6
const DEG_FOR_HOUR = 30

export const ClockAlternanative = () => {
    const [offset, setOffset] = useState<number>(0)

    const hoursBlock = useRef<HTMLDivElement | null>(null)
    const minutesBlock = useRef<HTMLDivElement | null>(null)
    const secondsBlock = useRef<HTMLDivElement | null>(null)

    const interval = useRef<any>(null)

    const changeOffset = (num: number): void => {
        setOffset(offset + num)
    }

    useEffect(() => {

        if (interval.current) {
            clearInterval(interval.current)
        }

        interval.current = setInterval(() => {
            const time: Date = new Date()
            time.setHours(time.getHours() + offset)

            const hours: number = time.getHours() * DEG_FOR_HOUR
            const minutes: number = time.getMinutes() * DEG_FOR_SECONDS_OR_MINUTES
            const seconds: number = time.getSeconds() * DEG_FOR_SECONDS_OR_MINUTES

            if (hoursBlock.current) {
                hoursBlock.current.style.transform = `rotateZ(${hours + (minutes / 12)}deg)`
            }


            if (minutesBlock.current) {
                minutesBlock.current.style.transform = `rotateZ(${minutes}deg)`
            }

            if (secondsBlock.current) {
                secondsBlock.current.style.transform = `rotateZ(${seconds}deg)`
            }

        }, 100)


        return () => {
            clearInterval(interval.current)
        }

    }, [])


    return (
        <>
            <div className={styles.clock}>
                <div ref={hoursBlock} className={styles.hour}>
                    <div className={styles.hours}></div>
                </div>
                <div ref={minutesBlock} className={styles.minute}>
                    <div className={styles.minutes}></div>
                </div>
                <div ref={secondsBlock} className={styles.second}>
                    <div className={styles.seconds}></div>
                </div>
            </div>
            <div>
                <Button click={() => changeOffset(-1)}>-1</Button>
                <Button click={() => changeOffset(1)}>+1</Button>
            </div>
        </>

    )
}
