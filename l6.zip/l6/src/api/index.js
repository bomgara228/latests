import axios from 'axios';

export const instance = axios.create({
    baseURL: 'https://jsonplaceholder.typicode.com',
    headers: {
        Authorization: 'Test dfvgdfk;glkjfg;l;flgkjhl'
    }
})

export const apiRequsts = {
    getUserInfo(id) {
        instance.get(`todos/${id}`)
        .then(({ data }) => {
            console.log("data", data)
            return data
        })
        .catch(e => console.log(e))
    }
}